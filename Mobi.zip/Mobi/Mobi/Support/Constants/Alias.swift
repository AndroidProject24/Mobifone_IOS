//
//  Alias.swift
//  Mobi
//
//  Created by HeoConUnIn on 10/2/17.
//  Copyright © 2017 HoangSon. All rights reserved.
//

import UIKit

let loginKey = "LOGIN"
let userKey = "USERPROFILE"
